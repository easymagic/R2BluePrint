<?php 

class View{
  
  function __set($k,$v){
    InjectViewClass::SetKey($k,$v);
  }
  
}