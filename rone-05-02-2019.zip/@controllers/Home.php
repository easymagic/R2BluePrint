<?php 
class Home extends Db{

   
   function Index(){
   	return 'Hello RONE.';
   }

   function Hello(){
   	return View('hello',array(
       'phones'=>$this->DbGet('phone_books')
   	));
   }

   function HelloAction(){
   	$msg = 'Hello action called.';
   	Redirect('hello?code=' . 1,true);
   	// Redirect('https://github.com/easymagic/R2BluePrint/blob/master/kernel.php',true);
   }



}