hello template .....
<?php 
 foreach ($phones as $k=>$phone){
?>
<div>
  <b>
    <?php echo $phone['phone_number']; ?>.
  </b>
</div>
<?php 
 }
?>
<form method="post">
  <input type="" name="name" placeholder="Name" />
  <button>Submit</button>
</form>