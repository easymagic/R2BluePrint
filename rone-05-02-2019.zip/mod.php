<?php
error_reporting(E_ALL);
session_start();


require_once('app-x/core/core.php');
require_once('config.php');
require_once('routes/web.php');

$__method__ = 'get';
if (isset($_POST) && !empty($_POST)){
 $__method__ = 'post';
}

//__request__
if (empty($_REQUEST['__request__'])){
  $_REQUEST['__request__'] = 'default';
}

 try {
   
   MatchRoute($__method__,$_REQUEST['__request__']);

 } catch (Exception $e) {
   
   echo $e->getMessage();

 }

