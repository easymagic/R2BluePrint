<?php 

class UserLogOut{
  

   function LogOut(){
    global $session;
    global $data;

    unset($session['user_session']);
    $data['message'] = 'You just logged out.';
   }

}