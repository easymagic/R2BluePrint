<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class UserFilterCompany{

   
     function FilterCompany(){
     	$this->EntityRead->SetWhere("role='company'");
     }


}