<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class UserFilterStaff{

   
     function FilterStaff(){
     	$this->EntityRead->SetWhere("role='staff'");
     }


}