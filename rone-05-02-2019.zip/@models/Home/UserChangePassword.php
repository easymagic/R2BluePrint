<?php 
/**
@Inject(@models/User/UserGetProfile);
*/
class UserChangePassword{

   
    function ChangePassword($id){
      $this->UserGetProfile->GetProfile($id);
    }


}