<?php 
/**
@Inject(@models/entityv2/EntityChangePassword);
*/

class UserChangePassword_Action{

  

  function ChangePassword_Action($id){
  	global $post;
  	global $data;

    $this->EntityRead->SetWhere("id=$id");
    $this->EntityCheckPassword->SetData($post);
    $this->EntityChangePassword->ChangePassword('user');
    
    // if (!isset($data['error']) || !$data['error']){
    //   $data['message'] = 'Password Changed';
    // }

  }


}