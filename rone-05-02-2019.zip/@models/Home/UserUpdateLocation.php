<?php 
/**
@Inject(@models/entityv2/EntityUpdate);
*/

class UserUpdateLocation{

  

   function UpdateLocation($lat,$lng,$current_address,$id){
   	 // global $postData;
   	 global $data;

     $this->EntityRead->SetWhere("id=$id");
     
     $this->EntityUpdate->SetData(array(
       'lat'=>$lat,
       'lng'=>$lng,
       'current_address'=>$current_address
     ));

     $this->EntityUpdate->DoUpdate('user');
     $data['message'] = 'Location updated.';
     
   }


}