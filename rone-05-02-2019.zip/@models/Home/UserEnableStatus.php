<?php 
/**
@Inject(@models/entityv2/EntityEnableField);
*/
class UserEnableStatus{
  

   function EnableStatus($id){
   	  global $data;
   	  $this->EntityRead->SetWhere("id=$id");
      $this->EntityEnableField->EnableField('user','status');
      $data['message'] = 'Account enabled.';
   }


}