<?php 
/**
@Inject(@models/entityv2/EntityLogin);
*/
class UserLogIn_Action{


  
  function LogIn_Action(){
  	global $post;

  	$this->EntityLogin->SetLoginFields('email','password');
  	$this->EntityLogin->SetData($post);
    $this->EntityLogin->Login('user');

  }


}