<?php 
/**
@Inject(@models/entityv2/EntityUpdate,
        @models/User/UserGetProfile,
        @models/User/UserUpdateCompanyLogo_Action);
*/

class UserUpdateProfile_Action{

  

   function UpdateProfile_Action($id){
   	 global $postData;
   	 global $data;

   	 $this->UserGetProfile->GetProfile($id);

   	 //for security reasons.
   	 unset($postData['email']);
   	 unset($postData['password']);

     $this->EntityRead->SetWhere("id=$id");
     $this->EntityUpdate->SetData($postData);
     $this->EntityUpdate->DoUpdate('user');

     if ($data['user_data']['role'] == 'company'){
       $this->UserUpdateCompanyLogo_Action->UpdateCompanyLogo_Action($id);
     }

     $data['message'] = 'Profile updated.';
     $data['error'] = false;

   }


}