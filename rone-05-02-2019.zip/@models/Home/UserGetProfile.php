<?php 
/**
@Inject(@models/entityv2/EntityReadOne);
*/


class UserGetProfile{


  function GetProfile($id){
   $this->EntityRead->SetWhere("id=$id");	
   $this->EntityReadOne->ReadOne('user');
  }


}