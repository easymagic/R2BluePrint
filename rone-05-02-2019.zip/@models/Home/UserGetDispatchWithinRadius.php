<?php
/**
@Inject(@models/entityv2/EntityRead);
*/
class UserGetDispatchWithinRadius{

   
    function GetDispatchWithinRadius($lat,$lng,$radiusKm){ //6371 => KM
      
      global $db_cols; 
      global $db_having;
      global $db_sort;

      $db_cols = "*,(
				    6371 * acos (
				      cos ( radians($lat) )
				      * cos( radians( lat ) )
				      * cos( radians( lng ) - radians($lng) )
				      + sin ( radians($lat) )
				      * sin( radians( lat ) )
				    )
				  ) AS distance";
       
       $db_having = "HAVING distance < $radiusKm";				  
       $db_sort = 'ORDER BY distance';

       $this->EntityRead->SetWhere("role='dispatcher' and status = 1");

       $this->EntityRead->Read('user');
 
    }



}