<?php 
/**
@Inject(@models/User/UserGetProfile);
*/
class UserUpdateProfile{

  

    function UpdateProfile($id){
     $this->UserGetProfile->GetProfile($id);
    }


}