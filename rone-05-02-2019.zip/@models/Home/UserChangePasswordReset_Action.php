<?php 
/**
@Inject(@models/entityv2/EntityChangePasswordReset);
*/


class UserChangePasswordReset_Action{
  


    function ChangePasswordReset_Action($id,$check){
      $this->EntityChangePasswordReset->ChangePasswordReset('user',$id,$check);
    }


}