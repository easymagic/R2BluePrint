<?php 

/*** Url Config***/
define('DEFAULT_CONTROLLER', 'Admin');
define('BASE_URL', 'http://localhost/rone/');


/****Database config*****/
// private static $db_server;
// private static $db_username;
// private static $db_password;
// private static $db_databasename;
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASENAME', 'db_wig');




/*** Middle-ware declaration ***/
RegisterMiddleWare('@middlewares/Db:Silent');