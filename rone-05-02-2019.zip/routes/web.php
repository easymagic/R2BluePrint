<?php 

RegisterRoute('get','/default','@controllers/Home:Index');

RegisterRoute('get','/hello','@controllers/Home:Hello');
RegisterRoute('get','/hello/(arg)','Foo:Get');
RegisterRoute('post','/hello','@controllers/Home:HelloAction');
RegisterRoute('get','/hello/(arg)/edit','Foo:Edit');
RegisterRoute('post','/hello/(arg)/edit/verb','Foo:EditPost');
