<?php 
class Home{

   
   function Index(){
   	// return array('welcomeMessage'=>'Hello RONE.');
    return View('home/index');

   }

   function Login(){
    if (isset($_SESSION['voter_session'])){
      Redirect('profile');
    }
    return View('home/login');
   }

   function Profile(){
    if (!isset($_SESSION['voter_session'])){
      Redirect('login');
    }
    $id = $_SESSION['voter_session']['id'];
    LoadClass($this,'@models/voter/VoterGet');
    return View('home/profile',array(
       'profile'=>$this->VoterGet->Get_($id)
    ));
   }

   function Mission(){
    return View('home/mission');
   }

   function Vision(){
    return View('home/vision');
   }

   function RegisteredMembers(){
    LoadClass($this,'@models/stats/StatsGetEstimate');
    return View('home/registered-members',array(
       'states'=>$this->StatsGetEstimate->GetEstimate()
    ));
   }

   // function Hello(){
   // 	return View('hello',array(
   //     'phones'=>$this->DbGet('phone_books')
   // 	));
   // }

   // function Hellov2($v){
   //   echo 'This is a value : ' . $v;
   // }

   // function HelloAction(){
   // 	$msg = 'Hello action called.';
   // 	Redirect('hello?code=' . 1,true);
   // 	// Redirect('https://github.com/easymagic/R2BluePrint/blob/master/kernel.php',true);
   // }


   // function SubjectCreate(){
   //    return View('check-create');
   // }



}