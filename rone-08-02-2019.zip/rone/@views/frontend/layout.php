<?php 
 
 // global $accounts;
 $themeDir = BASE_URL . 'theme1/';

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Door to Door</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo $themeDir; ?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="<?php echo $themeDir; ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Cabin:700' rel='stylesheet' type='text/css'>

    <!-- Custom styles for this template -->
    <link href="<?php echo $themeDir; ?>css/netplus.min.css" rel="stylesheet">
	<link href="<?php echo $themeDir; ?>css/responsiveness.min.css" rel="stylesheet">
	
  <script src="<?php echo $themeDir; ?>vendor/jquery/jquery.min.js"></script>	

  </head>

  <body id="page-top">
   
  

    <!-- Navigation -->
    <!-- <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top"><img src="img/Logo.png"></a>
       </div>
    </nav> -->

<nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav" style="padding: 3px;">
  <div class="container">
  <a class="navbar-brand" href="<?php echo BASE_URL; ?>"><img src="<?php echo BASE_URL; ?>images/logo.png" style="/* display: none; */width: 67px;border-radius: 26px;" ></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav" style="font-size: 13px;">
      <li class="nav-item active">
        <a class="nav-link" href="#">About DoortoDoor </a>
      </li>
      <li class="nav-item"><a href="<?php echo BASE_URL; ?>vision" class="nav-link">PDP Vision</a></li>
      <li class="nav-item"><a href="#" class="nav-link">Candidates</a></li>

      <?php 
        if (isset($_SESSION['voter_session'])){

          ?>

      <li class="nav-item"><a style="color: #ccc;font-size: 11px;" href="<?php echo BASE_URL; ?>profile" class="nav-link">
        Welcome , <?php echo $_SESSION['voter_session']['first_name']; ?>
      </a></li>
      <li class="nav-item" style="margin: 0;padding: 0;">
       <form method="post" action="<?php echo BASE_URL; ?>LogOut">
         <input type="hidden" name="cbs" value="profile" />
         <input type="hidden" name="cbe" value="profile" />
         <input style="font-size: 9px;padding: 5px;margin-top: 6px;border-radius: 4px;" type="submit" value="Log Out" class="btn btn-danger" />
       </form>
        <!-- <a href="<?php //echo BASE_URL; ?>LogOut" class="nav-link">Log Out</a> -->
      </li>


          <?php 

        }else{
          ?>


      <li class="nav-item"><a href="<?php echo BASE_URL; ?>login" class="nav-link">Sign in</a></li>
      <li class="nav-item"><a style="color: #43f443;" href="<?php echo BASE_URL; ?>#regview" class="nav-link">Sign up</a></li>

          <?php 
          
        }
      ?>

      <li class="nav-item"><a href="<?php echo BASE_URL; ?>registered-members" class="nav-link">Registered Members</a></li>


   
    </ul>
  </div>
	 	
</div>
</nav>



<?php 
 TemplateYield('mainContent','Loading...');
?>





  <section>
    <div class="container" >
      <p class="text-center" style="text-align: center;"><h3>I-REPORT/INSIGHTS</h3></p>
      <style type="text/css">
        .ireport img{
          border-radius: 6px;
        }
      </style>
       <div class="row ireport">
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="">
        <img src="<?php echo $themeDir; ?>img/atiku.jpg" class="img-rounded img-responsve" alt="Lights" style="width:100%">
        <div class="caption">
          <p>2019: Atiku declares for presidency</p>
        </div>
      </a>
    </div>
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="">
        <img src="<?php echo $themeDir; ?>img/saraki.jpg" class="img-rounded img-responsve" alt="Nature" style="width:100%">
        <div class="caption">
          <p>Atiku: Saraki, Tambuwal, Dankwambo get new PDP appointment ...</p>
        </div>
      </a>
    </div>
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="">
        <img src="<?php echo $themeDir; ?>img/sokoto.jpg" class="img-rounded img-responsve" alt="Fjords" style="width:100%">
        <div class="caption">
          <p>PDP takes Presidential campaign to Sokoto</p>
        </div>
      </a>
    </div>
  </div>
</div>
    </div>
  </section>

  <section id="send-payment">
          <div class="contact-container">
              <div class="container">
                <div class="row contact-box" style="color:#fff">
                  
               <div class="col-md-2">
                  <div class="footer-rhs contact-left">
                <a>Follow us</a>
               </div>
               </div>
               <div class="col-lg-4 ">
                
                  <div class="footer-rhs contact-left">
                    
                     <a href="#"><img src="<?php echo $themeDir; ?>img/fb.png" class="img-responsve" /></a>
                   <a href="#"><img src="<?php echo $themeDir; ?>img/tw.png"  class="img-responsve"  /></a>
                   <a href="#"><img src="<?php echo $themeDir; ?>img/ig.png"  class="img-responsve"  /></a>
                </div><!--end of footer-rhs-->
               </div>
                <div class="col-md-2">
                  <div class="footer-rhs contact-left">
                <a>Contact us</a>
               </div>
               </div>
                <div class="col-lg-4">
                  <div class="footer-rhs  contact-left">
                     <a href="#"><img src="<?php echo $themeDir; ?>img/phone.png"  class="img-responsve" /></a>
                   <a href="#"><img src="<?php echo $themeDir; ?>img/email.png"  class="img-responsve" /></a>
                </div><!--end of footer-rhs-->
               </div>
               </div><!--end of row-->
            </div>
            </div><!--end of footer-->

  </section>

  <section style="background-color: #9999994d; padding: 40px;">
    <div class="container text-center">
          <h6>Keep up to date with our latest news and information</h6>

      <form method="post" action="form.php">
      
        <div class="row">
            <div class="col-lg-4" style="margin:0 auto;">
             <div class="form-txt">
               <input type="text" class="form-control" id="business_name" placeholder="PRODUCT NAME" required />
             </div>
          </div>
          <div class="col-lg-4" style="margin:0 auto;">
             <div class="form-txt">
               <input type="text" class="form-control" id="business_name" placeholder="PRODUCT NAME" required />
             </div>
          </div>
          <div class="col-lg-4" style="margin:0 auto; ">
             <div class="form-txt">
            <button type="submit" border:none; class="btn btn-success btn-block" style="padding: 13px;border-radius: 3px;}">SEND</button>
          </div>
          </div>
         </div>
         </form>
    </div>
  </section>

  
  <section>
    <footer id="footer" class="footer-list">
        <div class="container">

          <div class="row">

            <!-- col #1 -->

            <!-- col #2 -->
            <div class="col-md-3">
              <h5 class="letter-spacing-1">DOOR-TO-DOOR</h5>
                  <ul class="list-unstyled">
                    <li><a class="block" href="#"> Contact</a></li>
                    <li><a class="block" href="#">I-Report</a></li>
                    <li><a class="block" href="<?php echo BASE_URL; ?>Home/Index#regview">Join</a></li>
                    <li><a class="block" href="#">Blog</a></li>
                    
                  </ul>

            </div>
              
                <div class="col-md-3">
                  <h5 class="letter-spacing-1">CAMPAIGN</h5>
                  <ul class="list-unstyled">
                    <li><a class="block" href="#">Presidential</a></li>
                    <li><a class="block" href="#">Governorship</a></li>
                    <li><a class="block" href="#">Senate</a></li>
                    <li><a class="block" href="#">House of Rep</a></li>
                    
                  </ul>

                </div>

                <div class="col-md-3">
                  <h5 class="letter-spacing-1">PARTY</h5>
                  <ul class="list-unstyled">
                    <li><a class="block" href="#"> About Us</a></li>
                    <li><a class="block" href="#">About PDP</a></li>
                    <li><a class="block" href="#"> Blog</a></li>
                    
                    
                  </ul>
                </div>

                <div class="col-md-3">
                  <h5 class="letter-spacing-1">RESOURCES</h5>
                  <ul class="list-unstyled">
                    <li><a class="block" href="#">Contact Us</a></li>
                    <li><a class="block" href="#"> Support</a></li>
                    <li><a class="block" href="#"> Privacy and Terms</a></li>
                    <li><a class="block" href="#"> Site Map</a></li>
                    
                  </ul>
                </div>

              

            </div>
            <!-- /col #2 -->

        </div>

      
      </footer>
  </section>
  <section>
         
       <div class="">
             <div class="footer-container">
              
                <div class="row">
                   
                     <div class="footer-lhs text-center">
                      © 2018 DOORTODOOR.
                 </div><!--end of footer-lhs-->
                
               </div><!--end of row-->
            </div><!--end of footer-->
        
       </div><!--end of conatiner-->
       
  </section>

 

    <!-- Bootstrap core JavaScript -->
    
    <script src="<?php echo $themeDir; ?>vendor/popper/popper.min.js"></script>
    <script src="<?php echo $themeDir; ?>vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="<?php echo $themeDir; ?>vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Google Maps API Key - Use your own API key to enable the map feature. More information on the Google Maps API can be found at https://developers.google.com/maps/ -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCRngKslUGJTlibkQ3FkfTxj3Xss1UlZDA&sensor=false"></script>

    <!-- Custom scripts for this template -->
    <script src="<?php echo $themeDir; ?>js/grayscale.min.js"></script>
    
    <script type="text/javascript">

      (function($){
        $(function(){
          $('[data-value]').each(function(){
            
            var vl = $(this).data('value');
            $(this).val(vl);
            
          });
        });
      })(jQuery);
      
    </script>

  </body>

</html>