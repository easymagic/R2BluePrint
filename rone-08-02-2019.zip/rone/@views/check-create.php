<?php 
 if (isset($_SESSION['response'])){
  echo $_SESSION['response']['message'];
  unset($_SESSION['response']);
 }
?>
<form method="post" action="<?php echo BASE_URL; ?>apiv1/CreateCheck">
	<input type="text" name="data[name]" placeholder="Check Name" />
	<button>Create</button>
	
	<input type="hidden" name="callbackSuccess" value="check-create" />
	<input type="hidden" name="callbackError" value="check-create" />

</form>