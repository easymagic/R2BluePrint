<?php 
class AccountThread{
    
    private $called = false;
    
    

	function Run(){

	 if (!$this->called){
       $this->called = true;
       $this->LoadVars(); 
	 }

	}



	function LoadVars(){

	 global $accounts;
	 global $session;
	 global $actionPermission;
	 global $permission;
	 global $data;

		$actionPermission = true;
		$permission = true;

		// $accounts = array('accounts'=>array('admin'));
		// $accounts = array();
		// if (isset($session['accounts'])){
		// 	echo "string...";
		//   $accounts = $session['accounts'];
		// }

	}

  
  


}