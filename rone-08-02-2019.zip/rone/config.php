<?php 

/*** Url Config***/
// define('DEFAULT_CONTROLLER', 'Admin');
// define('BASE_URL', 'http://timberfieldschoolslagosng.sch.ng/sandbox/');
define('BASE_URL', 'http://localhost/d2dc/rone/');
define('CALLBACK_URL', '/rone/');
// define('API_URL', '/d2dc/rone/');


/****Database config*****/
// private static $db_server;
// private static $db_username;
// private static $db_password;
// private static $db_databasename;
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASENAME', 'd2d_db');




/*** Middle-ware declaration ***/
// RegisterMiddleWare('@middlewares/Db:Silent');



/*** Helper Classes declarations ***/
RegisterHelperClasses('@declarations/Db');

RegisterHelperClasses('@declarations/entities/EntityAll');
RegisterHelperClasses('@declarations/entities/EntityGet');
RegisterHelperClasses('@declarations/entities/EntityUpdate');

RegisterHelperClasses('@declarations/entities/EntityCreate');
RegisterHelperClasses('@declarations/entities/EntityDelete');
RegisterHelperClasses('@declarations/entities/EntityDisableField');
RegisterHelperClasses('@declarations/entities/EntityEnableField');
RegisterHelperClasses('@declarations/entities/EntityLogin');
RegisterHelperClasses('@declarations/entities/EntityRegister');
RegisterHelperClasses('@declarations/entities/EntityCheckPassword');
RegisterHelperClasses('@declarations/entities/EntityChangePassword');

RegisterHelperClasses('@declarations/entities/EntityUpdateUpload');
RegisterHelperClasses('@declarations/entities/EntityLogOut');

