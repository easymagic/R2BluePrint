<?php 

class EntityUpdateUpload extends EntityUpdate{


    
     function UpdateUpload($table,$id,$imagefield,$path){
  
         $check = $this->DoUpload($imagefield,$path);

         if (!$check['error']){
            
            $this->Update($table,$id,$check['data']);

         }

         return $check;


     }


   private function GetSalt($id){
     $r = md5(uniqid() . md5($id));
     $r = substr($r, -7);
     return $r;
   }

   private function DoUpload($name,$path){
     
     $files = $_FILES;
     $result = array('data'=>array());
     $result['error'] = true;
     $result['message'] = 'Upload failed.';


     if (isset($files[$name])){
      
       $name_ = $this->GetSalt($files[$name]['name']) . '_' . $files[$name]['name'];

       if (move_uploaded_file($files[$name]['tmp_name'], $path . $name_)){
          // $this->SetData(array($name=>$name_));
       	  $result['data'][$name] = $name_;
          $result['error'] = false;
          $result['message'] = 'Upload succeed.';
       }
     }

     return $result;

   }



}