<?php 

class EntityLogOut{

  

   function LogOut($entity){
     unset($_SESSION[$entity . '_session']);
     return array(
      'message'=>'Just Logged out',
      'error'=>false
     );
   }


}