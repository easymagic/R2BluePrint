<?php 

class EntityLogin extends Db{

  

   function Login($table,$usernamefield1,$usernamefield2,$passwordfield,$data=array()){
      
       $criteria = " ( ($usernamefield1 = '$data[$usernamefield1]' OR $usernamefield2 = '$data[$usernamefield2]') && $passwordfield = '$data[$passwordfield]' ) ";
       
       $this->SetWhere($criteria);

       $result = array('session'=>array());
       $result['error'] = false;
       
   	
	    if (!empty($this->GetWhere())){
	    	
	    	$rst = $this->DbGet($table);
	    	if (count($rst) > 0){

		    	$result['session'] = $rst[0];
		    	$result['message'] = 'Welcome (:';

		    	if (isset($result['session']['status']) && empty($result['session']['status'])){
	               $result['message'] = 'Please verify your account from the link sent.';
	               $result['error'] = true;
		    	}else{
	               $_SESSION[$table . '_session'] = $result['session'];
		    	}


	    	}else{

		    	$result['message'] = 'Invalid login!';
		    	$result['error'] = true;	    		

	    	}

	    }else{

	    	$result['message'] = 'Invalid login!';
	    	$result['error'] = true;

	    }
     
      return $result;

   }



}