<?php 

class EntityCheckPassword{


   function CheckPassword($data=array()){
     
     $result = array('data'=>array());
   	 if (isset($data['password1']) && isset($data['password2'])){
      if ($data['password1'] == $data['password2'] && !empty($data['password1'])){
       $result['message'] = 'Passwords OK.';
       $result['error'] = false;
       $result['data']['password'] = $data['password1']; //pick one of the passwords.
      }else{
	      $result['message'] = 'Invalid Password!';
	      $result['error'] = true;      	
      }
   	 }else{
      $result['message'] = 'Invalid Password Vars!';
      $result['error'] = true;
   	 }

   	 return $result;

   }


}