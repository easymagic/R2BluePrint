<?php 

class EntityGet extends Db{


    function Get($table,$id){
      $this->SetWhere("(id = $id)");
      $r = $this->DbGet($table);
      if (count($r) > 0){
       return $r[0];
      }else{
       return array(); 
      }	
      // return $this->DbGet($table);
    }

}