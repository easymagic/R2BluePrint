<?php 

class EntityUpdate extends Db{


   
    function Update($table,$id,$data=array()){
      $this->SetWhere("id=$id");
      $this->DbUpdate($table,$data);
      return array(
        'error'=>false,
        'message'=>'saved'
      );
    }


}