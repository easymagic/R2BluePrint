<?php 

class EntityEnableField extends Db{

  

   function EnableField($table,$field){

   	
	    if (!empty($this->GetWhere())){
	       $this->DbUpdate($table,array(
            $field=>1
	       ));
	    }


   }


}