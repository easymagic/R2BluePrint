<?php 

class EntityAll extends Db{


    function All($table){
      return $this->DbGet($table);
    }

}