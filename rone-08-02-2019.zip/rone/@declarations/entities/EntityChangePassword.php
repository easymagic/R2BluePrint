<?php 

class EntityChangePassword extends EntityUpdate{

   
    function ChangePassword($table,$id,$data=array()){
         LoadClass($this,'@declarations/entities/EntityCheckPassword');
    	 $check = $this->EntityCheckPassword->CheckPassword($data);
    	 if (!$check['error']){
           $this->Update($table,$id,array(
            'password'=>$check['data']['password']
           ));
           $check['message'] = 'Password successfully changed.';
    	 }
    	 return $check;

    }

}