<?php 

class EntityDelete extends Db{

   // function SetWhere(){

   // } 

   function Delete($table){
    
    if (!empty($this->GetWhere())){
       $this->DbDelete($table);
    }

   }


}