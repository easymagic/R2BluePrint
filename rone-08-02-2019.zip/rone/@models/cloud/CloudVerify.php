<?php 

class CloudVerify{

  
   private $data = array();

	function CleanKey($r){
	  $r = explode('</td>', $r);
	  return $r[0];
	}

	function CleanValue($r){
	  $r = explode('>', $r);
	  $r = $r[1];
	  $r = explode('<', $r);
	  $r = $r[0];
	  return $r;
	}


	function Verify($state_id,$lastname,$vin){

		set_time_limit(60);

		$result = array('data'=>array());

		$url = "http://52.23.145.6/web/site/votersearch?state_id=$state_id&lastname=$lastname&vin=$vin&year=&day=&month=&" . uniqid();
	 
	 $r = file_get_contents($url);

	// $config = array();
	// $config['error'] = false;
	$result['message'] = 'Verification successful.';
	$result['error'] = false;
	// echo $r;
	$r = explode('<td>', $r);

	if (count($r) > 1){

		array_shift($r);
		// array_pop($r);

		$key = '';
		$value = '';
		foreach ($r as $k=>$v){
		  
		  if (pow(-1, $k) == 1){
		    $key = $this->CleanKey($v);
		  }else{
		    $value = $this->CleanValue($v);
		  }

		  $result['data'][$key] = $value;

		}
	  
	}else{
		$result['error'] = true;
		$result['message'] = 'Verification Failed!!!';
		// $result['url'] = $url;
	}

	// print_r($data);

	// return $config;

	return $result;
	  
	}  



}