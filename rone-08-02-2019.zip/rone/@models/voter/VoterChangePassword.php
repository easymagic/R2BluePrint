<?php 

class VoterChangePassword extends EntityChangePassword{

    
    function ChangePassword_(){
     $id = $_SESSION['voter_session']['id'];
     return parent::ChangePassword('voter',$id,$_POST);
    }
    


}