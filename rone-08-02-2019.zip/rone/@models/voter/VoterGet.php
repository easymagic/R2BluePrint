<?php 

class VoterGet extends EntityGet{

   

   function Get_($id){
   	return parent::Get('voter',$id);
   }  



}