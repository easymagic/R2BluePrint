<?php 

class VoterLogOut extends EntityLogOut{
  

   function LogOut_(){
   	return parent::LogOut('voter');
   }


}