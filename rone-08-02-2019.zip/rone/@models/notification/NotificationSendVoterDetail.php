<?php 

class NotificationSendVoterDetail extends EntityGet{

 

   function SendVoterDetail($id){
     
     LoadClass($this,'@declarations/entities/EntitySendMail');
     
     $voterData = $this->Get('voter',$id);
     
     $mailTemplateSettings  = array(
      'first_name'=>$voterData['first_name'],
      'last_name'=>$voterData['last_name'],
      'polling_unit'=>$voterData['polling_unit'],
      'vin'=>$voterData['vin'],
      'date_of_birth'=>$voterData['date_of_birth'],
      'gender'=>$voterData['gender']
     );

     $mailTemplate = View('notification/voter-detail',$mailTemplateSettings);

     $this->EntitySendMail->SetSubject('VERIFICATION SUCCESS FROM DOOR2DOOR CONNECT');
     $this->EntitySendMail->SetMessage($mailTemplate);
     $this->EntitySendMail->SetTo($voterData['email']);
     $this->EntitySendMail->SetFrom('info@r2soft.com.ng');
     $this->EntitySendMail->SendMail();


   }



}