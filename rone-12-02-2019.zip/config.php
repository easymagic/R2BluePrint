<?php 

/*** Url Config***/
// define('DEFAULT_CONTROLLER', 'Admin');
// define('BASE_URL', 'http://timberfieldschoolslagosng.sch.ng/sandbox/');
define('BASE_URL', 'http://door2doorconnect.com.ng.r2soft.com.ng/');
define('CALLBACK_URL', '');
// define('API_URL', '/d2dc/rone/');


/****Database config*****/
// private static $db_server;
// private static $db_username;
// private static $db_password;
// private static $db_databasename;
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'ydetbkzc_door2door_user');
define('DB_PASSWORD', '$5zIjy[DMHcf');
define('DB_DATABASENAME', 'ydetbkzc_door2door_connect_db');
                                            // 'ydetbkzc_door2door_user',
                                            // '$5zIjy[DMHcf',
                                            // 'ydetbkzc_door2door_connect_db'); // or 



/*** Middle-ware declaration ***/
// RegisterMiddleWare('@middlewares/Db:Silent');



/*** Helper Classes declarations ***/
// RegisterHelperClasses('@declarations/Db');

// RegisterHelperClasses('@declarations/entities/EntityAll');
// RegisterHelperClasses('@declarations/entities/EntityGet');
// RegisterHelperClasses('@declarations/entities/EntityUpdate');

// RegisterHelperClasses('@declarations/entities/EntityCreate');
// RegisterHelperClasses('@declarations/entities/EntityDelete');
// RegisterHelperClasses('@declarations/entities/EntityDisableField');
// RegisterHelperClasses('@declarations/entities/EntityEnableField');
// RegisterHelperClasses('@declarations/entities/EntityLogin');
// RegisterHelperClasses('@declarations/entities/EntityRegister');
// RegisterHelperClasses('@declarations/entities/EntityCheckPassword');
// RegisterHelperClasses('@declarations/entities/EntityChangePassword');

// RegisterHelperClasses('@declarations/entities/EntityUpdateUpload');
// RegisterHelperClasses('@declarations/entities/EntityLogOut');

