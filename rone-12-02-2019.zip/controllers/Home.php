<?php 
namespace controllers;

class Home{

   
   function Index(){
   	// return array('welcomeMessage'=>'Hello RONE.');
    // return '000000';
    return View('home/index');

   }

   function Login(){
    if (isset($_SESSION['voter_session'])){
      Redirect('profile');
    }
    return View('home/login');
   }

   function Profile(){
    if (!isset($_SESSION['voter_session'])){
      Redirect('login');
    }
    $id = $_SESSION['voter_session']['id'];
    // LoadClass($this,'@models/voter/VoterGet');
    
    $obj = new \models\voter\VoterGet;

    return View('home/profile',array(
       'profile'=>$obj->Get_($id)
    ));
   }

   function Mission(){
    return View('home/mission');
   }

   function Vision(){
    return View('home/vision');
   }

   function RegisteredMembers(){
    // LoadClass($this,'@models/stats/StatsGetEstimate');
    $obj  = new \models\stats\StatsGetEstimate;

    return View('home/registered-members',array(
       'states'=>$obj->GetEstimate()
    ));
   }



}