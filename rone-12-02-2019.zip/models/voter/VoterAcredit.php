<?php
namespace models\voter;


class VoterAcredit extends \declarations\entities\EntityRegister{

  

   function Acredit(){
   	 
   	 // LoadClass($this,'@models/cloud/CloudVerify');
   	 $obj = new \models\cloud\CloudVerify;

   	 $state_id = $_POST['data']['state_id'];
   	 $lastname = $_POST['data']['name_on_voter_card'];
   	 $vin = $_POST['data']['last_8_pvc_pin'];

   	 if (strlen($vin) >= 8){

   	 	$vin = substr($vin, -7);

		   	 $check1 = $obj->Verify($state_id,$lastname,$vin);

		   	 if (!$check1['error']){

		   	  $_POST['data']['first_name'] = $check1['data']['Firstname'];
		   	  $_POST['data']['last_name'] = $check1['data']['Lastname'];
		   	  $_POST['data']['polling_unit'] = $check1['data']['Polling Unit'];
		   	  $_POST['data']['vin'] = $check1['data']['VIN'];
		   	  $_POST['data']['date_of_birth'] = $check1['data']['Date of Birth'];
		   	  $_POST['data']['gender'] = $check1['data']['Gender'];


			   $check2 = $this->Register($table='voter',$duplicatefield1='email',$duplicatefield2='vin',$data=$_POST['data'],$passwordData=$_POST);

			   // LoadClass($this,'@models/notification/NotificationSendVoterDetail');

			   $obj = new \models\notification\NotificationSendVoterDetail;

			   if (!$check2['error']){
		         $obj->SendVoterDetail($check2['data']['newID']);
		         $check2['message'] = 'Verification Succesful.';
		         __clear(); //clears the form-post bucket.
			   }else{
			   	 $check2['message'] = 'An account (' . $check2['data']['email'] . ') with this vin-number or E-mail already exists!';
			   }

			   return $check2; 

		   	 }else{

		   	 	return $check1;

		   	 }


   	 }else{

   	 	return array(
           'message'=>'Your VIN-Number not 8-chars in length!',
           'error'=>true
   	 	);

   	 }
   	 



   }



}