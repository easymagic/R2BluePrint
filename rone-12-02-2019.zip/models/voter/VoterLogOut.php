<?php
namespace models\voter;

class VoterLogOut extends \declarations\entities\EntityLogOut{
  

   function LogOut_(){
   	return parent::LogOut('voter');
   }


}