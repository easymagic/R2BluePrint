<?php
namespace models\voter;

class VoterUpdate extends \declarations\entities\EntityUpdate{


  function Update_(){
  	$id = $_SESSION['voter_session']['id'];
  	$data = array();
  	$data['phone'] = $_POST['data']['phone'];
  	$result = parent::Update('voter',$id,$data);
  	$result['message'] = 'Phone updated successfully.';
  	return $result;
  }
  

}