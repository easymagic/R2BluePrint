<?php
namespace models\voter;

class VoterLogin extends \declarations\entities\EntityLogin{

  



    function Login_(){
    	
    	if (!isset($_POST['vin'])){
          $_POST['vin'] = '';
    	}
    	
    	if (!isset($_POST['email'])){
         $_POST['email'] = '';
    	}

        if (empty($_POST['vin'])){
         $_POST['vin'] = $_POST['email'];
        }
    	
    	

    	return $this->Login($table='voter',$usernamefield1='vin',$usernamefield2='email',$passwordfield='password',$_POST);
    }



}