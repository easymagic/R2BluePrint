<?php 
/**
@Inject(@models/entityv2/EntityRead);
*/

class EntityDelete{

   

   function DoDelete($entity){

     global $db_where;

     if (!empty($db_where)){
      DbDelete($entity);
     }
     
   }


}