<?php 

class EntityRead{

   
   function Init(){
    global $db_where_array;
    if (!isset($db_where_array)){
      $db_where_array = array();
    }

    InstallPlugin($this);

   }   

   function Read($entity){     
     global $db_records;
     global $data;
     global $db_where;

     // echo $db_where . '....';
     // echo "$entity";
     DbRead($entity);

     $data[$entity . '_data'] = $db_records;
 
     return $db_records;
   }

   function SetWhere($criteria){
     global $db_where;
     global $db_where_array;
     
     $db_where_array[] = $criteria;

     $db_where = " where (" . implode(' and ', $db_where_array) . ") ";
     // echo $db_where;
     // die($db_where);
   }

   function DbResetVars(){
    global $db_where_array;
    $db_where_array = array();
    // echo 'Db reset hook called.';
   }


}