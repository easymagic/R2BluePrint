<?php 

class V2Model{

  
  
  //subject
  function CreateSubject(){

  }

  function AllSubject(){

  }

  function GetSubject(){

  }

  function UpdateSubject(){

  }

  function GetSubject(){

  }


  function DeleteSubject(){


  }


  //User (Admin)
  function RegisterUser(){

  }

  function LoginUser(){

  }

  function GetUser(){

  }

  function AllUser(){

  }

  function UpdateUser(){

  }

  function UpdateAccountUser(){

  }

  function DeleteUser(){

  }

  function EnableUser(){

  }

  function DisableUser(){

  }

  function ChangePasswordUser(){

  }

  function ChangePasswordAccountUser(){

  }


  ///student
  function RegisterStudent(){

  }

  function LoginStudent(){

  }

  function AllStudent(){

  }

  function GetStudent(){

  }

  function UpdateStudent(){

  }

  function UpdateAccountStudent(){

  }

  function DeleteStudent(){

  }

  function EnableStudent(){

  }

  function DisableStudent(){

  }

  function ChangePasswordStudent(){

  }

  function ChangePasswordAccountStudent(){

  }



  //Test
  function CreateTest(){

  }

  function GetTest(){

  }

  function AllTest(){

  }

  // function 













}