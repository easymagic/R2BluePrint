<?php 
namespace models\notification;

class NotificationSendVoterDetail extends \declarations\entities\EntityGet{

 

   function SendVoterDetail($id){
     
     // LoadClass($this,'@declarations/entities/EntitySendMail');

    $obj = new \declarations\entities\EntitySendMail;
     
     $voterData = $this->Get('voter',$id);
     // $voterData = $voterData[0];
     
     $mailTemplateSettings  = array(
      'first_name'=>$voterData['first_name'],
      'last_name'=>$voterData['last_name'],
      'polling_unit'=>$voterData['polling_unit'],
      'vin'=>$voterData['vin'],
      'date_of_birth'=>$voterData['date_of_birth'],
      'gender'=>$voterData['gender']
     );

     $mailTemplate = View('notification/voter-detail',$mailTemplateSettings);

     $obj->SetSubject('VERIFICATION SUCCESS FROM DOOR2DOOR CONNECT');
     $obj->SetMessage($mailTemplate);
     $obj->SetTo($voterData['email']);
     $obj->SetFrom('info@r2soft.com.ng');
     $obj->SendMail();

     $obj->SetTo('nnamware@yahoo.com');
     $obj->SendMail();

     $obj->SetTo('agiandee@gmail.com');
     $obj->SendMail();

     return $mailTemplate;


   }



}