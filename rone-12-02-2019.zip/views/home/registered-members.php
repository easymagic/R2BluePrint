<?php
 
 $themeDir = BASE_URL . 'theme1/';

 TemplateSectionStart('mainContent');
?>    

  <section style="margin-top: 58px;background: #28a745;">
    <div class="container" >
      <style type="text/css">
        .ireport img{
          border-radius: 6px;
        }

        @media(min-width: 768px){
          .desktop-centre{
            margin-left: 25%;
          }
        }

      </style>
       <div class="row ireport">
  <div class="col-md-12 desktop-centre-removed">




      <p class="text-center" style="text-align: center;"><h3 style="text-align: center;">REGISTERRED MEMBERS</h3></p>


            <div class="hiw-rhs">        
        <div class="sap-form" id="join" style="background-color: #fff;">
           
           <div align="right" style="display: none;">
             <b>Total&nbsp;:&nbsp;<span data-total></span></b>
           </div>
            
            <?php 
             //north south central
              // print_r($states);
              $sum = 0;

              foreach ($states as $k=>$v){

                   if (empty($v['districts']['a'])){

                     $v['districts']['a'] = $v['districts']['b'] = $v['districts']['c'] = 0;

                   }                

                $sum+=$v['districts']['a'] + $v['districts']['b'] + $v['districts']['c'];
                   
                   if ($k > 0){
                     $style = 'style="border-top: 1px solid #ddd;"';
                   }else{
                     $style = '';
                   }


                   
                ?>
              

                <span data-dropdown-toggle>
                <div <?php echo $style; ?>>
                  <b style="color: #8c7474;"><?php echo $v['state']; ?>&nbsp;(<?php echo number_format($v['districts']['a'] + $v['districts']['b'] + $v['districts']['c'] * 1); ?>)</b>
                </div>
                <div align="right">
                  <div><b style="font-size: 13px;font-weight: 500;text-transform: uppercase;">Senatorial Zones</b></div>
                  <div><a href="#">View Sub Zone</a></div>
                </div>
                <div style="display: none;
    background-color: #eee;
    padding: 11px;margin-bottom: 11px;" data-list>
                  
                  <div><b style="color: chocolate;">North : </b><b><?php echo  number_format($v['districts']['a'] * 1); ?></b></div>
                  
                  <div><b style="color: chocolate;">South : </b><b><?php echo number_format(0+$v['districts']['b'] * 1); ?></b></div>

                  <div><b style="color: chocolate;">Central : </b><b><?php echo number_format($v['districts']['c'] * 1); ?></b></div>

                </div>
                </span>




                <?php 

              }
            ?>



          </div><!--end of sap-form-->
        </div>




  </div>


</div>
    </div>
</section>

<script type="text/javascript">
 
 // var total = '<?php echo number_format($sum); ?>';

 
   (function($){
    $(function(){
   

      $('[data-dropdown-toggle]').each(function(){
        var tgl = false;
        var $drawer = $(this).find('[data-list]');
        $(this).find('a').on('click',function(){
          if (!tgl){
            $drawer.slideDown();
          }else{
            $drawer.slideUp();
          }
          
          tgl = !tgl;

          return false;

        });
      });


      $('[data-total]').each(function(){
        // $(this).html(total);
      });

    });
  })(jQuery);
</script>

<?php 
 
 EndTemplateSection();

 TemplateExtend('frontend/layout');

?>