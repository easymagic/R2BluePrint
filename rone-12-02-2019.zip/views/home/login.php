<?php
 
 $themeDir = BASE_URL . 'theme1/';

 TemplateSectionStart('mainContent');
?>    

	<section style="margin-top: 58px;background: #28a745;">
		<div class="container" >
			<style type="text/css">
				.ireport img{
					border-radius: 6px;
				}

        @media(min-width: 768px){
          .desktop-centre{
            margin-left: 25%;
          }
        }

			</style>
			 <div class="row ireport">
  <div class="col-md-6 desktop-centre">


			       	<?php
			       	 
			       	 if (isset($_SESSION['response']['message'])){
                      $message = $_SESSION['response']['message'];
                      $error = $_SESSION['response']['error'];
                      unset($_SESSION['response']['message']);
			       	 } 

                     if (isset($message)){
                     	if (isset($error) && $error){
                         $cls = 'danger';
                     	}else{
                     	 $cls = 'success';	
                     	}
                       // global $data;
                       // print_r($data);
                     ?>
                      <div class="alert alert-<?php echo $cls; ?>" style="margin-top: 11px;"><?php echo $message; ?></div>  
                     <?php 	
                     }
			       	?>


      <p class="text-center" style="text-align: center;"><h3 style="text-align: center;">LOGIN</h3></p>


            <div class="hiw-rhs">
        
        <div class="sap-form" id="join">
         
            <form method="post" action="<?php echo BASE_URL; ?>apiv1/Login" >

            	<input type="hidden" name="cbs" value="login" />
            	<input type="hidden" name="cbe" value="login" />
               
            
<style type="text/css">
  .form-txt input{
    color: #fff !important;
  }
</style>

             
             <div class="form-txt">
             <input name="email" type="text" class="form-control" placeholder="EMAIL ADDRESS"  value="<?php echo __('email'); ?>" required />
             </div>
             
            
              <div class="form-txt">
             <input name="password" type="password" class="form-control" id="business_name" placeholder="Password"  value="<?php echo __('password'); ?>" required />
             </div>



            <button type="submit" border:none; class="submit-btn"  style="background-color: #fff; color: #000; border-radius: 3px;">Login</button>
            
            </form>
          </div><!--end of sap-form-->
        </div>




  </div>


</div>
		</div>
</section>

<?php 
 
 EndTemplateSection();

 TemplateExtend('frontend/layout');

?>