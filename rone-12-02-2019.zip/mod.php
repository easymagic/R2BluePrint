<?php
error_reporting(E_ALL);
session_start();


function __autoload($file){
 $file = $file . '.php';
 // echo $file;
 $file = explode('\\', $file);
 $file = implode('/', $file);
 
 if (file_exists($file)){
 	// echo $file;
   include_once($file);
 }
}


require_once('app-x/core/core.php');
require_once('config.php');
require_once('routes/web.php');
// require_once('messages/messageDefinitions.php');

$__method__ = 'get';
if (isset($_POST) && !empty($_POST)){
 $__method__ = 'post';
}

//__request__
if (empty($_REQUEST['__request__'])){
  $_REQUEST['__request__'] = 'default';
}

 try {
   
   $r = MatchRoute($__method__,$_REQUEST['__request__']);

   // echo $r;

   if (is_object($r) || is_array($r)){

	   if ($__method__ == 'post'){


	   	if (isset($r['error'])){

	   	  	

	   	  $_SESSION['response'] = array('form'=>array(),'formData'=>array());

	   	  if (isset($_POST['data'])){
             $_SESSION['response']['formData'] = $_POST['data'];
	   	  }
	   	  $_SESSION['response']['form'] = $_POST;

	   	  if (isset($r['message'])){
	   	  	$_SESSION['response']['message'] = $r['message'];
	   	  }
	   	  $_SESSION['response']['error'] = $r['error'];
            
           if (!$r['error']){
		    if (isset($_REQUEST['cbs'])){
		     Redirect($_REQUEST['cbs']);
		    }
		   }else{
		    if (isset($_REQUEST['cbe'])){
	         Redirect($_REQUEST['cbe']);
		    }
		   }

	   	}else{

		    if (isset($_REQUEST['cb'])){
		     Redirect($_REQUEST['cb']);
		    }

	   	}


	   }

       echo json_encode($r);

   }else{

       echo $r;

   }


 } catch (Exception $e) {
   
   echo $e->getMessage();

 }

