<?php
namespace declarations\entities;

class EntityCreate extends \declarations\Db{

   
   function Create($table,$data){
      
      $this->DbCreate($table,$data);

      return array(
        'newID'=>$this->newID
      );

   }

}