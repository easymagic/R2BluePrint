<?php 
namespace declarations\entities;

class EntityDisableField extends \declarations\Db{

  

   function DisableField($table,$field){

   	
	    if (!empty($this->GetWhere())){
	       $this->DbUpdate($table,array(
            $field=>0
	       ));
	    }


   }


}