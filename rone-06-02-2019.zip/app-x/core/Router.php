<?php 

/**
@Inject(app-x/core/ObjectProxy,
        app-x/core/PluginLoader,
        app-x/core/PayloadService,
        app-x/core/RequestResponse,
        app-x/core/EmailQueue,
        @services/PluginAdapter,
        app-x/core/@threads/DataThread,
        app-x/core/@threads/RequestThread,
        app-x/core/@threads/DatabaseThread,
        app-x/core/@threads/AccountThread,
        app-x/core/@threads/RedirectThread,
        app-x/core/@threads/MailQueueThread);
*/

class Router{

  private $plugins;
  private $obj;
  private $name;
  private $method;
  private $args;


  private function InitBootUpThreads(){
   PushThread($this->DataThread); 
   PushThread($this->DatabaseThread);
   PushThread($this->AccountThread);
   PushThread($this->RedirectThread);
   PushThread($this->RequestThread);
   PushThread($this->MailQueueThread);

   InstallPlugin($this); //to handle session garbage of the data-api.

   PushLib('app-x/core/@libs/db');

  }

  private function AutoLoadModels(){
    global $autoloadModels;
    foreach ($autoloadModels as $k=>$model){

      InjectKey($model);

    }
  }
   


  function Dispatch(){

    global $data;
    global $json;
    global $actionPermission;
    global $permission;
    // global $accounts;
    global $contentType;
    global $routeName;
    global $routeAction;

    // global $routeArgs;
    global $buffer;
    // global $redirect;

    $this->AutoLoadModels();

    $this->InitBootUpThreads();

    
    CallAction('Framework_Start');

    LoadLibs();

    
    $method = $routeAction;
    


    CallAction('Page_Init');

    if (ActionTrigerred()){

      CallAction($method . '_ActionPermission');

       if ($actionPermission){

         CallAction('Before_' . $method . '_Action');        
         CallAction($method . '_Action',$ucModel=true); //action point
       }else{
         throw new Exception("You do not have the permission to call this action!");
       }

    }else{

       CallAction($method . '_NoAction');

    }

    

    CallAction($method . '_Permission');

    if ($permission){


       CallAction('Before_' . $method);
       CallAction($method,$ucModel=true); //node point.
       ///users can develop their own framework theme loading pattern.
       RunThemes();

       

    }else{
      
      throw new Exception("You do not have the permission to view this page!");

    }


    CallAction('Page_Destroy');


    //check content-type
    if ($contentType == 'json'){
      foreach ($data as $k=>$v){
         if (!is_object($v)){
           $json[$k] = $v;
         }
      }
      $buffer = json_encode($json);
    }

  }


  function Page_Destroy(){
    global $session;
    global $data;
    if (isset($session['data'])){
      unset($session['data']);
      $data = array();
    }   
  }






}