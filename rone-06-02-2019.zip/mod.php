<?php
error_reporting(E_ALL);
session_start();


require_once('app-x/core/core.php');
require_once('config.php');
require_once('routes/web.php');
// require_once('messages/messageDefinitions.php');

$__method__ = 'get';
if (isset($_POST) && !empty($_POST)){
 $__method__ = 'post';
}

//__request__
if (empty($_REQUEST['__request__'])){
  $_REQUEST['__request__'] = 'default';
}

 try {
   
   $r = MatchRoute($__method__,$_REQUEST['__request__']);

   // echo $r;

   if (is_object($r) || is_array($r)){

	   if ($__method__ == 'post'){


	   	if (isset($r['error'])){

	   	  	

	   	  $_SESSION['response'] = array();

	   	  if (isset($r['message'])){
	   	  	$_SESSION['response']['message'] = $r['message'];
	   	  }
	   	  $_SESSION['response']['error'] = $r['error'];
            
           if (!$r['error']){
		    if (isset($_REQUEST['callbackSuccess'])){
		     Redirect($_REQUEST['callbackSuccess']);
		    }
		   }else{
		    if (isset($_REQUEST['callbackError'])){
	         Redirect($_REQUEST['callbackError']);
		    }
		   }

	   	}else{

		    if (isset($_REQUEST['callback'])){
		     Redirect($_REQUEST['callback']);
		    }

	   	}


	   }

       echo json_encode($r);

   }else{

       echo $r;

   }


 } catch (Exception $e) {
   
   echo $e->getMessage();

 }

