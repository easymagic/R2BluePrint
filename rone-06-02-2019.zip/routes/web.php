<?php 

RegisterRoute('get','/default','@controllers/Home:Index');

RegisterRoute('get','/hello','@controllers/Home:Hello');
RegisterRoute('get','/hello/(arg)','@controllers/Home:Hellov2');
RegisterRoute('post','/hello','@controllers/Home:HelloAction');
RegisterRoute('get','/hello/(arg)/edit','Foo:Edit');
RegisterRoute('post','/hello/(arg)/edit/verb','Foo:EditPost');

RegisterRoute('get','/subject-create','@controllers/Home:SubjectCreate');

RegisterRoute('post','/SubjectCreate','@models/subject/SubjectCreate:Create');
