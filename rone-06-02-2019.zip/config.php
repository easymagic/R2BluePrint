<?php 

/*** Url Config***/
define('DEFAULT_CONTROLLER', 'Admin');
define('BASE_URL', 'http://timberfieldschoolslagosng.sch.ng/sandbox/');


/****Database config*****/
// private static $db_server;
// private static $db_username;
// private static $db_password;
// private static $db_databasename;
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'xnlkymkj_timber_user');
define('DB_PASSWORD', '2SdV2tC%#9X!');
define('DB_DATABASENAME', 'xnlkymkj_timber_db');




/*** Middle-ware declaration ***/
// RegisterMiddleWare('@middlewares/Db:Silent');



/*** Helper Classes declarations ***/
//RegisterHelperClasses