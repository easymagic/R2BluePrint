<?php 
 if (isset($_SESSION['response'])){
  echo $_SESSION['response']['message'];
  unset($_SESSION['response']);
 }
?>
<form method="post" action="/sandbox/SubjectCreate">
	<input type="text" name="data[name]" placeholder="Subject Name" />
	<button>Create</button>
	
	<input type="hidden" name="callbackSuccess" value="subject-create" />
	<input type="hidden" name="callbackError" value="subject-create" />

</form>