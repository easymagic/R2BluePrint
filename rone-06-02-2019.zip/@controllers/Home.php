<?php 
class Home{

   
   function Index(){
   	return array('welcomeMessage'=>'Hello RONE.');
   }

   function Hello(){
   	return View('hello',array(
       'phones'=>$this->DbGet('phone_books')
   	));
   }

   function Hellov2($v){
     echo 'This is a value : ' . $v;
   }

   function HelloAction(){
   	$msg = 'Hello action called.';
   	Redirect('hello?code=' . 1,true);
   	// Redirect('https://github.com/easymagic/R2BluePrint/blob/master/kernel.php',true);
   }


   function SubjectCreate(){
      return View('subject-create');
   }



}